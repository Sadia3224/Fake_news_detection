from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import PassiveAggressiveClassifier
from sklearn.model_selection import train_test_split
import pandas as pd
import pickle

# Load dataset
df = pd.read_csv('news.csv')
x = df['text']
y = df['label']

# Vectorize the text data
vector = TfidfVectorizer(stop_words='english', max_df=0.7)
X = vector.fit_transform(x)

# Split the data
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Train the model
model = PassiveAggressiveClassifier()
model.fit(x_train, y_train)

# Save the model and vectorizer
with open('fake_news_model.pkl', 'wb') as f:
    pickle.dump(model, f)

with open('vectorizer.pkl', 'wb') as f:
    pickle.dump(vector, f)

print("✅ Model and vectorizer saved successfully!")
